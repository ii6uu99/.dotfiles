#git init
git add .
git commit -m "6666"
git push -u origin master
