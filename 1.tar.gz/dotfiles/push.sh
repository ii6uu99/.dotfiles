#git init
git commit -m "."
git remote add origin https://github.com/ii6uu99/.dotfiles.git
git push -u origin master