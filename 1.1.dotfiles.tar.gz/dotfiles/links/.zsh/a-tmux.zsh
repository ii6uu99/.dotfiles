alias a-t="vim /.dotfiles/links/.zsh/a-tmux.zsh"   #vim编辑本文件

alias tmux="TERM=screen-256color-bce tmux"
