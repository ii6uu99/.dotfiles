#git init
#git config --global user.email "ii6uu99@163.com"
#git config --global user.name "ii6uu99"
#git remote add origin "https://ii6uu99:hzm373566162@github.com/ii6uu99/.dotfiles.git"

git add .
#git status
git commit -m "ne"
#git checkout master
#git remote set-url origin https://github.com/ii6uu99/.dotfiles.git
git push -u origin master
