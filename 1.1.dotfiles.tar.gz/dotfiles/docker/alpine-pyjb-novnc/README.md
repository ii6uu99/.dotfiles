# noVNC Docker image

Alpine X11 server and HTML5 VNC client with autofocus. Based on docker pull psharkey/novnc.
