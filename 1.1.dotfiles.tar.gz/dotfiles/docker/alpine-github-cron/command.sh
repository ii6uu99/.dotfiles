#!/bin/bash

set -e

eval $COMMAND
