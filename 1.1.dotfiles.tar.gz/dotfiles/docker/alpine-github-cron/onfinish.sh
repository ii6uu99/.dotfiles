#!/bin/bash

set -e

echo "Job finished: $(date)"
