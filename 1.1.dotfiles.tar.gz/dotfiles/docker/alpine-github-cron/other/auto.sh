###git环境配置
git config --global user.name "ii6uu99"
git config --global user.email "ii6uu99@163.com"
git remote add origin "https://ii6uu99:hzm373566162@github.com/ii6uu99/.dotfiles.git"


git init
git add .
git commit -m "ne"
git remote add origin https://github.com/ii6uu99/.dotfiles.git
git push -u origin master