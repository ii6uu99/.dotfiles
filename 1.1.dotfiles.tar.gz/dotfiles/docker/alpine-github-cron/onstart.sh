#!/bin/bash

set -e

echo "Job started: $(date)"
