# toolbox

A ubuntu based Toolset for Docker.

    docker run -d --restart=always --privileged --network=host --pid=host --name toolbox lihaixin/toolbox
