#!/bin/bash -eu
exec jupyter notebook --no-browser --ip=*
