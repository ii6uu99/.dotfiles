alpine linux jupyterlab
========================

# setup
docker pull youske/alpine-jupyterlab


# run

docker run -it --rm youske/alpine-jupyterlab shell

shellmode
docker run -it --rm youske/alpine-jupyterlab shell
