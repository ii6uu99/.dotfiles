var util = require('util');

console.log('works');
console.log(util.inspect(process.env));
console.log(util.inspect(process.versions));
