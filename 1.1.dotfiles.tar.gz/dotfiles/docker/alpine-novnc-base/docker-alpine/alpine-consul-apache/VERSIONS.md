# alpine-consul-apache

This file contains all software versions, that correspond to a version of this image itself.

## Latest

Same as v1.0.0.

Usage: `smebberson/alpine-consul-apache` or `smebberson/alpine-consul-apache:latest`.

## v1.0.0

- [smebberson/alpine-consul-base: v1.1.0][smebbersonalpineconsulbase110]
- [apache: v2.4.16][apache]

Usage: `smebberson/alpine-consul-apache:1.0.0`.

[apache]: httsp://httpd.apache.org/
[smebbersonalpineconsulbase110]: https://github.com/smebberson/docker-alpine/tree/0cb63b4702b5e3c684e9c2e6c90dca454e29bb79/alpine-consul-base
