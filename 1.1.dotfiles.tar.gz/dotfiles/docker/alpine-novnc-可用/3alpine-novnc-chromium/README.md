# docker-novnc-chromium
Docker container running Alpine linux with a full screen chromium + noVNC
