# 系统环境一键安装包
一杯咖啡的时间，马上进入工作环境




### 安装软件
- 安装jdk1.8
- 安装xx-net 翻墙
- charles 抓包
- docker环境
- jetbrains（c,php,java,go,web,python）

### 支持系统
- deepin
- ubuntu LTS
### 说明
deepin滚动支持，ubuntu支持最新 LTS


